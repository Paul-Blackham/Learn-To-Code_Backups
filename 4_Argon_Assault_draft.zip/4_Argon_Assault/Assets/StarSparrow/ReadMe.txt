Thank you for downloading this asset!
This is a free sample of this collection:
https://www.assetstore.unity3d.com/#!/content/81341

Please do feel free to join the discussion at:
https://forum.unity.com/threads/released-modular-spaceships-collection.518276

Changes in Version 1.5:
-Added 4 examples.
-Added 3 different colors.
-Albedo textures are now editable in Photoshop.
-Added Substance Painter file
-Improved textures and added details
-Added the spaceship examples in modular form as well as the single GameObject form.